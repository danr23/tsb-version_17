function loadTsbT(a, b, c) {
setTimeout(function() {
document.getElementById("loadTsbT").innerHTML = "Loading TSB...";
}, a);
setTimeout(function() {
document.getElementById("loadTsbT").innerHTML = "Loading TSB..";
}, b);
setTimeout(function() {
document.getElementById("loadTsbT").innerHTML = "Loading TSB.";
}, c);
}
loadTsbT(100, 200, 300);
loadTsbT(400, 500, 600);
loadTsbT(700, 800, 900);
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 2px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
document.getElementById("loadTsb").innerHTML = "TSB";
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 4px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 100);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 6px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 200);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 8px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 300);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 10px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 400);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 12px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 500);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 10px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 600);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 8px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 700);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 6px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 800);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 4px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 900);
setTimeout(function() {
document.getElementById("loadTsb").setAttribute('style', 'border: #00cc00 2px solid;color: #00cc00;border-radius:25px;font-size: 100px;');
}, 1000);
setTimeout(function() {
location.href = 'http://192.168.1.2/user/tsb/realIndex.htm';
}, 1050);
